Description:
The project is a simulation game inspired by the highly popular Food Network cooking competition, Chopped, in which competitors are given a basket of several mystery ingredients and challenged to create a dish utilizing them. 

How to run:
Run the 'littleCulinary.py' file. You may need to download chrome driver (linked here for free download) and change the driver location in webScraping.py to redirect to this path.
https://chromedriver.chromium.org/downloads
 
Which libraries:

Libraries: N/A

Shortcut features:
During the cooking mode, instead of waiting for the timer to run out, you can click 'n' and move onto the scoring page. 